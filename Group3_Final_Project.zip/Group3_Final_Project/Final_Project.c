#include <REG52.h>
#include <stdio.h> 
#include <Final_Project_Header.h>


void main(){
	TMOD = 0x11;
	TH0 = 0; 
	TL0 = 0;
	TR0 = 1;								//start timer0
	TF0 = 0;
	TH1 = 0; 
	TL1 = 0;
	TR1 = 1;								//start timer1
	IT0 = 1;								//Make external interrupt0 an edge-triggered
	
	//enable interupt for timer0, timer1, and external interrupt0
	IE	 = 0x8B;		
	InitPWM();              // Start PWM
	InitTimer0();

	while(1){
		
	}
}