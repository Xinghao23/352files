//Defining ports 
sbit PWMoutput = P3^4;
sbit input1 = P0^1; 
sbit input2 = P0^2;
sbit input3 = P0^0; 
sbit encoderMotor = P3^2;
sbit decoder1A = P1^0; 
sbit decoder1B = P1^1; 
sbit decoder1C = P1^2; 
sbit decoder1D = P1^3; 
sbit decoder2A = P2^0; 
sbit decoder2B = P2^1; 
sbit decoder2C = P2^2; 
sbit decoder2D = P2^3; 
sbit decoder3A = P3^0; 
sbit decoder3B = P3^1; 
sbit decoder3C = P3^5; 
sbit decoder3D = P3^3; 
//Global variables
unsigned char input = 0;
unsigned char	numOfPeriods;
unsigned char timerCount;
unsigned short RPM;
unsigned short RPM1;
unsigned short RPM2;
unsigned short RPM3;
float DutyCycle;
unsigned char PWM = 0;	  //value0 to 255 
unsigned int temp = 0;    // Used inside Timer0 ISR
unsigned short PWMFreq = 257;	 // Highest possible PWM Frequency
unsigned short kp;
unsigned short error; 
unsigned short adjustingPower; 
unsigned short lastError;
unsigned short integral; 
unsigned short adjustingPWM;
unsigned short kd;
unsigned short ki; 

//Function to return the thousands number in RPM 
int convertEncoderThousand(int num){
  int a = (num/1000)%10;
	return a;
}
//Function to return the hundreds number in RPM 
int convertEncoderHundred(int num){
	int a = (num/100)%10;
	return a; 
}
//Function to return the tenth number in RPM 
int convertEncoderTenth(int num){
	int a = (num/10)%10;
	return a; 
}

//Function to display the 7 segments 
void displayLCD(double LCD, int input){
	if(LCD == 1){
		switch(input){
		case 0:
			decoder1A = 0; 
			decoder1B = 0; 
			decoder1C = 0; 
			decoder1D = 0; 
			break;
		case 1: 
			decoder1A = 1; 
			decoder1B = 0; 
			decoder1C = 0; 
			decoder1D = 0; 
			break;
		case 2: 
			decoder1A = 0; 
			decoder1B = 1; 
			decoder1C = 0; 
			decoder1D = 0; 
			break;
		case 3:
			decoder1A = 1; 
			decoder1B = 1; 
			decoder1C = 0; 
			decoder1D = 0; 
			break;
		case 4: 
			decoder1A = 0; 
			decoder1B = 0; 
			decoder1C = 1; 
			decoder1D = 0; 
			break;
		case 5: 
			decoder1A = 1; 
			decoder1B = 0; 
			decoder1C = 1; 
			decoder1D = 0; 
			break;
		case 6: 
			decoder1A = 0; 
			decoder1B = 1; 
			decoder1C = 1; 
			decoder1D = 0; 
			break;
		case 7: 
			decoder1A = 1; 
			decoder1B = 1; 
			decoder1C = 1; 
			decoder1D = 0; 
			break;
		case 8:
			decoder1A = 0; 
			decoder1B = 0; 
			decoder1C = 0; 
			decoder1D = 1; 
			break;
		case 9:
			decoder1A = 1; 
			decoder1B = 0; 
			decoder1C = 0; 
			decoder1D = 1; 
			break;
		default: 
			break;
		}
	}
	else if(LCD == 2){
		switch(input){
		case 0:
			decoder2A = 0; 
			decoder2B = 0; 
			decoder2C = 0; 
			decoder2D = 0; 
			break;
		case 1: 
			decoder2A = 1; 
			decoder2B = 0; 
			decoder2C = 0; 
			decoder2D = 0; 
			break;
		case 2: 
			decoder2A = 0; 
			decoder2B = 1; 
			decoder2C = 0; 
			decoder2D = 0; 
			break;
		case 3:
			decoder2A = 1; 
			decoder2B = 1; 
			decoder2C = 0; 
			decoder2D = 0; 
			break;
		case 4: 
			decoder2A = 0; 
			decoder2B = 0; 
			decoder2C = 1; 
			decoder2D = 0; 
			break;
		case 5: 
			decoder2A = 1; 
			decoder2B = 0; 
			decoder2C = 1; 
			decoder2D = 0; 
			break;
		case 6: 
			decoder2A = 0; 
			decoder2B = 1; 
			decoder2C = 1; 
			decoder2D = 0; 
			break;
		case 7: 
			decoder2A = 1; 
			decoder2B = 1; 
			decoder2C = 1; 
			decoder2D = 0; 
			break;
		case 8:
			decoder2A = 0; 
			decoder2B = 0; 
			decoder2C = 0; 
			decoder2D = 1; 
			break;
		case 9:
			decoder2A = 1; 
			decoder2B = 0; 
			decoder2C = 0; 
			decoder2D = 1; 
			break;
		default: 
			break;
		}
	}
	else if(LCD == 3){
	switch(input){
		case 0:
			decoder3A = 0; 
			decoder3B = 0; 
			decoder3C = 0; 
			decoder3D = 0; 
			break;
		case 1: 
			decoder3A = 1; 
			decoder3B = 0; 
			decoder3C = 0; 
			decoder3D = 0; 
			break;
		case 2: 
			decoder3A = 0; 
			decoder3B = 1; 
			decoder3C = 0; 
			decoder3D = 0; 
			break;
		case 3:
			decoder3A = 1; 
			decoder3B = 1; 
			decoder3C = 0; 
			decoder3D = 0; 
			break;
		case 4: 
			decoder3A = 0; 
			decoder3B = 0; 
			decoder3C = 1; 
			decoder3D = 0; 
			break;
		case 5: 
			decoder3A = 1; 
			decoder3B = 0; 
			decoder3C = 1; 
			decoder3D = 0; 
			break;
		case 6: 
			decoder3A = 0; 
			decoder3B = 1; 
			decoder3C = 1; 
			decoder3D = 0; 
			break;
		case 7: 
			decoder3A = 1; 
			decoder3B = 1; 
			decoder3C = 1; 
			decoder3D = 0; 
			break;
		case 8:
			decoder3A = 0; 
			decoder3B = 0; 
			decoder3C = 0; 
			decoder3D = 1; 
			break;
		case 9:
			decoder3A = 1; 
			decoder3B = 0; 
			decoder3C = 0; 
			decoder3D = 1; 
			break;
		default: 
			break;
		}
	}
}
//Function for external port interrupte on port 3.3 
void ExternalInterrupt1() interrupt 0 {											
	numOfPeriods++;
}

//Timer for flywheel RPM calculations
void timer1() interrupt 3 {
	timerCount++;
	
	if (timerCount == 7) { 			//1 sec = 1E6us
		timerCount = 0;						//1E6/1.085/2^16 = 14 loops per sec
															//									7 loops per 1/2 sec
		
		RPM3 = RPM2;
		RPM2 = RPM1;
		RPM1 = (numOfPeriods)*60;		//(60sec/min)*(2/sec) /(2periods/rev) 
		numOfPeriods = 0;					  //																			
		RPM = (RPM1 + RPM2 + RPM3)/3;
		displayLCD(1, convertEncoderThousand(RPM1)); 
		displayLCD(2, convertEncoderHundred(RPM1));
		displayLCD(3, convertEncoderTenth(RPM1));
	}
	TL1 = 0;
	TH1 = 0;
	TF1 = 0;
	TR1 = 1;
}

// Timer0 initialize
void InitTimer0(void)
{
	TMOD &= 0xF0;    // Clear 4bit field for timer0
	TMOD |= 0x01;    // Set timer0 in mode 1 = 16bit mode
	
	TH0 = 0x00;      // First time value
	TL0 = 0x00;      // Set arbitrarily zero
	
	ET0 = 1;         // Enable Timer0 interrupts
	EA  = 1;         // Global nterrupt enable
	
	TR0 = 1;         // Start Timer 0
}

// PWM initialize
void InitPWM(void)
{
	PWM = 0;         // Initialize with 0% duty cycle
	InitTimer0();    // Initialize timer0 to start generating interrupts
					 // PWM generationcode is written inside the Timer0 ISR
}
//PWM Function 
void Timer0_ISR (void) interrupt 1   
{
	TR0 = 0;    // Stop Timer 0
  
	input = P0;
	input = input&0x07;		//only read first 3 pins of port1 (0x07 = 0000 0111)
	switch (input) {
		case(0): 
			DutyCycle = 1;  //2400   111
			kp = -0.7;
			adjustingPWM = 0; 
			break;	//0% 
		case(1): 
			DutyCycle = 0.9; //2160  011
			kp = 0.7;
			adjustingPWM = 0; 
			break; //10%
		case(2): 
			DutyCycle = 0.7; //1680   101
			kp = 0.9;
			adjustingPWM = 80;
			break;	//30%
		case(3): 
			DutyCycle = 0.6; //1440   001
			kp = 0.9;
			adjustingPWM = 82; 
			break; //40% 
		case(4): 
			DutyCycle = 0.5; //1200    110
			kp = 0.9;
			adjustingPWM = 84; 
			break; //50% 
		case(5): 
			DutyCycle = 0.3; //720    010 
			kp = 0.9;
			adjustingPWM = 20; 
			break;	//70% 
		case(6): 
			DutyCycle = 0.2; //360     100 
			kp = 0.9;
			adjustingPWM = 0; 
			break; //80% 
		case(7): DutyCycle = 0; //0   000
			adjustingPWM = 0; 
			break;	//100% 
		default: 
			DutyCycle = 0.5;
			kp = 0.7;
			adjustingPWM = 0; 
			break;
	}
/*switch (input) {
		case(0): 
			DutyCycle = 1;  //2400   111
			kp = -0.7;
			adjustingPWM = 0; 
			break;	//0% 
		case(1): 
			DutyCycle = 0.9; //2160  011
			kp = 0.7;
			adjustingPWM = 0; 
			break; //10%
		case(2): 
			DutyCycle = 0.7; //1680   101
			kp = 0.9;
			adjustingPWM = 0;
			break;	//30%
		case(3): 
			DutyCycle = 0.6; //1440   001
			kp = 0.9;
			adjustingPWM = 0; 
			break; //40% 
		case(4): 
			DutyCycle = 0.5; //1200    110
			kp = 0.9;
			adjustingPWM = 0; 
			break; //50% 
		case(5): 
			DutyCycle = 0.3; //720    010 
			kp = 0.9;
			adjustingPWM = 0; 
			break;	//70% 
		case(6): 
			DutyCycle = 0.2; //360     100 
			kp = 0.9;
			adjustingPWM = 0; 
			break; //80% 
		case(7): DutyCycle = 0; //0   000
			adjustingPWM = 0; 
			break;	//100% 
		default: 
			DutyCycle = 0.5;
			kp = 0.7;
			adjustingPWM = 0; 
			break;
	}
*/
	// Proportional Control
	if(RPM != DutyCycle*2400){
	error = RPM - DutyCycle*2400; 
	adjustingPower = error*kp;
	
	// PWM
	PWM = (255*DutyCycle-adjustingPower - adjustingPWM);
	}
	if(PWM>255){PWM=255;}
	else if(PWM<0) {PWM = 0;}
    
	if(PWMoutput)	// if PWM_Pin is high
	{
		PWMoutput = 0;
		temp = (255-PWM)*PWMFreq ;
		TH0  = 0xFF - (temp>>8)&0xFF;
		TL0  = 0xFF - temp&0xFF;	
	}
	
	else	     // if PWM_Pin is low
	{
		PWMoutput = 1;
		temp = PWM*PWMFreq;
		TH0  = 0xFF - (temp>>8)&0xFF;
		TL0  = 0xFF - temp&0xFF;
	}

	TF0 = 0;     // Clear the interupt flag
	TR0 = 1;     // Start Timer 0
}




